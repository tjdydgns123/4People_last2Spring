package com.models;

public class Result {

}
