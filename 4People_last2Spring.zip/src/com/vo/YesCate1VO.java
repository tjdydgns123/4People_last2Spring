package com.vo;

public class YesCate1VO {
	private String cate_num = null;
	private String cate_bunryu = null;
	public String getCate_num() {
		return cate_num;
	}
	public void setCate_num(String cate_num) {
		this.cate_num = cate_num;
	}
	public String getCate_bunryu() {
		return cate_bunryu;
	}
	public void setCate_bunryu(String cate_bunryu) {
		this.cate_bunryu = cate_bunryu;
	}
}
