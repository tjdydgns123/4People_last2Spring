package com.vo;

public class CalendarVO {
	  private String cal_contents  = null;
	  private String cal_no        = null;
	  private String cal_title     = null;
	  private String cal_startdate = null;
	  private String cal_starttime = null;
	  private String cal_enddate   = null;
	  private String cal_endtime   = null;
	  private String cal_category  = null;
	  private String mem_id        = null;
	  private String cal_color     = null;
	  
	public String getCal_contents() {
		return cal_contents;
	}
	public void setCal_contents(String cal_contents) {
		this.cal_contents = cal_contents;
	}
	public String getCal_no() {
		return cal_no;
	}
	public void setCal_no(String cal_no) {
		this.cal_no = cal_no;
	}
	public String getCal_title() {
		return cal_title;
	}
	public void setCal_title(String cal_title) {
		this.cal_title = cal_title;
	}
	public String getCal_startdate() {
		return cal_startdate;
	}
	public void setCal_startdate(String cal_startdate) {
		this.cal_startdate = cal_startdate;
	}
	public String getCal_starttime() {
		return cal_starttime;
	}
	public void setCal_starttime(String cal_starttime) {
		this.cal_starttime = cal_starttime;
	}
	public String getCal_enddate() {
		return cal_enddate;
	}
	public void setCal_enddate(String cal_enddate) {
		this.cal_enddate = cal_enddate;
	}
	public String getCal_endtime() {
		return cal_endtime;
	}
	public void setCal_endtime(String cal_endtime) {
		this.cal_endtime = cal_endtime;
	}
	public String getCal_category() {
		return cal_category;
	}
	public void setCal_category(String cal_category) {
		this.cal_category = cal_category;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getCal_color() {
		return cal_color;
	}
	public void setCal_color(String cal_color) {
		this.cal_color = cal_color;
	}
	
	
}
