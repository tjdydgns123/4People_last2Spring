package com.vo;

public class MeetRoomVO {        
	private String mr_no         = null;
	private String mr_loc        = null;
	private String mr_capacity   = null;
	private String mr_name       = null;
	private String mr_master     = null;
	private String mr_starttime  = null;
	private String mr_endtime    = null;
	private String mr_memo       = null;
	private String mr_facility   = null;
	private String mr_image      = null;
	
	public String getMr_no() {
		return mr_no;
	}
	public void setMr_no(String mr_no) {
		this.mr_no = mr_no;
	}
	public String getMr_loc() {
		return mr_loc;
	}
	public void setMr_loc(String mr_loc) {
		this.mr_loc = mr_loc;
	}
	public String getMr_capacity() {
		return mr_capacity;
	}
	public void setMr_capacity(String mr_capacity) {
		this.mr_capacity = mr_capacity;
	}
	public String getMr_name() {
		return mr_name;
	}
	public void setMr_name(String mr_name) {
		this.mr_name = mr_name;
	}
	public String getMr_master() {
		return mr_master;
	}
	public void setMr_master(String mr_master) {
		this.mr_master = mr_master;
	}
	public String getMr_starttime() {
		return mr_starttime;
	}
	public void setMr_starttime(String mr_starttime) {
		this.mr_starttime = mr_starttime;
	}
	public String getMr_endtime() {
		return mr_endtime;
	}
	public void setMr_endtime(String mr_endtime) {
		this.mr_endtime = mr_endtime;
	}
	public String getMr_memo() {
		return mr_memo;
	}
	public void setMr_memo(String mr_memo) {
		this.mr_memo = mr_memo;
	}
	public String getMr_facility() {
		return mr_facility;
	}
	public void setMr_facility(String mr_facility) {
		this.mr_facility = mr_facility;
	}
	public String getMr_image() {
		return mr_image;
	}
	public void setMr_image(String mr_image) {
		this.mr_image = mr_image;
	}
	
	

}
